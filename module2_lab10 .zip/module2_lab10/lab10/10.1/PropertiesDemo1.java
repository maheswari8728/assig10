package propertiesPackage;

public class PropertiesDemo1 {
	
	

}
