
public class EmployeeException extends Exception {
	
	

	public EmployeeException() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("Entered Salary is less than 3000");
	}

	
}