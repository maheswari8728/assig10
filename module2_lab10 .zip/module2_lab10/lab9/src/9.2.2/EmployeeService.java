
public interface EmployeeService {
	String employeeService();
}
